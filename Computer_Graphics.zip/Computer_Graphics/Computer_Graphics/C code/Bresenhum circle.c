#include <stdio.h>
#include <graphics.h>
#include <math.h>

int main() {
    int gd = DETECT, gm;
    int x, y, xc, yc, r, p, xmax, ymax;

    printf("Input center of the circle (xc yc): ");
    scanf("%d%d", &xc, &yc);

    printf("Input the radius of the circle (r): ");
    scanf("%d", &r);

    initgraph(&gd, &gm, "");

    xmax = getmaxx();
    ymax = getmaxy();

    // স্ক্রিনের মাঝখানে কোঅর্ডিনেট অ্যাক্সিস বা অক্ষ আঁকা
    line(xmax / 2, 0, xmax / 2, ymax);
    line(0, ymax / 2, xmax, ymax / 2);

    p = 3 - (2 * r);
    x = 0;
    y = r;

    while (x <= y) {
        // বৃত্তের ৮টি প্রতিসম (Symmetric) পয়েন্টে পিক্সেল ড্র করা
        putpixel((xmax / 2 + xc + x), (ymax / 2 - yc + y), WHITE);
        putpixel((xmax / 2 + xc - x), (ymax / 2 - yc + y), WHITE);
        putpixel((xmax / 2 + xc + x), (ymax / 2 - yc - y), WHITE);
        putpixel((xmax / 2 + xc - x), (ymax / 2 - yc - y), WHITE);
        putpixel((xmax / 2 + xc + y), (ymax / 2 - yc + x), WHITE);
        putpixel((xmax / 2 + xc - y), (ymax / 2 - yc + x), WHITE);
        putpixel((xmax / 2 + xc + y), (ymax / 2 - yc - x), WHITE);
        putpixel((xmax / 2 + xc - y), (ymax / 2 - yc - x), WHITE);

        if (p < 0) {
            x = x + 1;
            p = p + (4 * x) + 6;
        } else {
            x = x + 1;
            y = y - 1;
            p = p + (4 * (x - y)) + 10;
        }
    }

    getch();
    closegraph();
    return 0;
}